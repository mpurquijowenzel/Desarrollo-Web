# Reto de las cajas_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/MARIA-PAULA-URQUIJOWENZEL/pen/vELWeXB](https://codepen.io/MARIA-PAULA-URQUIJOWENZEL/pen/vELWeXB).

