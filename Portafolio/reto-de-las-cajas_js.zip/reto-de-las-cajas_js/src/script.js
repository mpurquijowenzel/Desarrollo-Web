// Inicio del script para el reto de las cajas, DOM JSS//

//1. Cuando haga click en el btn-cajas-título se cambie el título de las cajas//

document.getElementById("btn-cajas-titulo").addEventListener("click",()=>
 {
  const titulocaja =   
        document.getElementById("titulo-cajas");
  titulocaja.textContent = "Paulette";
});

//2. Cambiar el color de la caja//

document.getElementById("btn-color-cajas").addEventListener("click",()=>
 {
  const cajas =
   document.getElementsByClassName("caja");
  for (let i = 0; i < cajas.length; i++)
    {
      cajas[i].style.backgroundColor = "#B427F5";
    }
});

//3. Cambiar el color de la primera caja//

document.getElementById("btn-primera-caja").addEventListener("click",()=>
 {
  const primeracaja =
        document.querySelector(".caja");
  primeracaja.style.backgroundColor = "green";
});                                                         

//4. Cambiar el color al borde de las cajas//

document.getElementById("btn-borde").addEventListener("click",()=>
 {
  const bordecaja =
        document.querySelectorAll(".caja");
  bordecaja.forEach(caja =>
                    {
                caja.style.border =  "10px dotted red";
                    });
});                                                     